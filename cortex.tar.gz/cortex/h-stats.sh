#!/usr/bin/env bash

. /hive-config/wallet.conf

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
