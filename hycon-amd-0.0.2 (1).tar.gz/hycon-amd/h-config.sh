#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

#. debug.conf
#. /hive-config/rig.conf
#. /hive-config/wallet.conf
#CUSTOM_URL="pooladdress"
#CUSTOM_TEMPLATE="username"
#CUSTOM_PASS="4000"
#{"num":"1"},{"num":"2"}
#CUSTOM_USER_CONFIG='[{"num":"1"},{"num":"2"}]'

cd /hive/custom/hycon-amd
#echo $CUSTOM_USER_CONFIG
#echo $PWD

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1

jq --argfile f1 config_global.json --arg f2 ${CUSTOM_PASS} --arg f3 ${CUSTOM_URL} -n '$f1 | .pools[0].pass = $f2 | .pools[0].url = $f3' > config_user.json
conf=`jq --argfile f1 config_user.json --arg f2 ${CUSTOM_TEMPLATE} -n '$f1 | .pools[0].user = $f2'`.
[[ ! -z $WORKER_NAME ]] && conf=$(sed "s/%WORKER_NAME%/$WORKER_NAME/g" <<< "$conf")
echo $conf | jq . -M > config_user.json
#[[ ! -z $CUSTOM_USER_CONFIG ]] && jq --argfile f1 config.json --arg f2 '${CUSTOM_USER_CONFIG}' -n '$f1 | .threads |= .+ []' -M > config.json
echo $CUSTOM_USER_CONFIG | jq . -M > config_threads.json
conf=`jq --argfile f1 config_user.json --argfile f2 config_threads.json -n '$f1 | .threads += $f2'`
echo $conf | jq .  -M > config.json



