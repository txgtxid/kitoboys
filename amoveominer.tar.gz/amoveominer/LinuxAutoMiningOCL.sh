#!/bin/bash
export LD_LIBRARY_PATH=/hive/miners/custom/amoveominer
while :; do
   if pidof -x "AmoveoMinerManOCL" >/dev/null; then
     echo "AmoveoMinerManOCL is running"
   else
     ./AmoveoMinerManOCL -n=256 -b=72 -s=65536
   fi
   sleep 1
done
