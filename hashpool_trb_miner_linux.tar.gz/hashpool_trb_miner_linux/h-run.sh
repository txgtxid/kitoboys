#!/usr/bin/env bash

export LD_LIBRARY_PATH=/hive/lib:/usr/local/cuda/lib64/:/usr/local/cuda/lib64/stubs:/hive/miners/custom/epic:$LD_LIBRARY_PATH
export LIBRARY_PATH=/usr/local/cuda/lib64/:/usr/local/cuda/lib64/stubs:$LIBRARY_PATH
export PATH=/usr/local/go/bin:/usr/local/cuda/bin/:$PATH

# pkgs='librocksdb5.8'
# if ! dpkg -s $pkgs >/dev/null 2>&1; then
#     sudo apt-get update
#     sudo apt install librocksdb5.8 -y
# fi

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
#[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not
# found${NOCOLOR}" && exit 1
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

[[ -f $CUSTOM_LOG_BASENAME".log" ]] && rm $CUSTOM_LOG_BASENAME".log"

conf=`head -n 1 $CUSTOM_CONFIG_FILENAME`

./run.sh $conf
