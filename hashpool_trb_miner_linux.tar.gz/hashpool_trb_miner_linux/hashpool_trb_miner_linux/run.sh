#/bin/sh
./hashpool_trb_miner mine
