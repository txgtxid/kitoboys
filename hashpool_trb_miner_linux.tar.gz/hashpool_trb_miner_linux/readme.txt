1. Modify config.json file , change publicAddress to your TRB miner address
2. Run  ./run.sh

