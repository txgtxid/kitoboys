#!/bin/bash
export LD_LIBRARY_PATH=/hive/miners/custom/MCM
while :; do
   if pidof -x "MCM" >/dev/null; then
     echo "MCM is running"
   else
     ./MCM
   fi
   sleep 1
done
