#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

export LD_LIBRARY_PATH=/hive/miners/custom/MCM

./LinuxAutoMiningOCL.sh $(< /hive/miners/custom/$CUSTOM_NAME/$CUSTOM_NAME.conf) $@ 2>&1 | tee $CUSTOM_LOG_BASENAME.log
