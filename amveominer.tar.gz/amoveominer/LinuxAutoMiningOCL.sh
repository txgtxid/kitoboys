#!/bin/bash
export LD_LIBRARY_PATH=/hive/miners/custom/amoveominer
while :; do
   if pidof -x "AmoveoMinerManOCL" >/dev/null; then
     echo "AmoveoMinerManOCL is running"
   else
     ./AmoveoMinerManOCL
   fi
   sleep 1
done
