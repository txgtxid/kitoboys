#!/bin/bash

ALGO=hns/bl2bsha3
POOL=handshake.6block.com:7701
ADDRESS=donate          # Change this to your 6block account name.
USERNAME=$txgtxid.J
PWD=x
MODE=opencl
VENDOR=nvidia           # card type, options: amd,nvidia
./6miner -a $ALGO -o $POOL -u $USERNAME -p $PWD -m $MODE --opcl-vendor=$VENDOR 