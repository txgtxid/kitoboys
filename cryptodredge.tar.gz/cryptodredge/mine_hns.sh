#!/bin/bash

ALGO=hns/bl2bsha3
POOL=handshake.6block.com:7701
ADDRESS=donate          # Change this to your 6block account name.
USERNAME=txgtxid.l
PWD=x
MODE=opencl
VENDOR=nvidia           # card type, options: amd,nvidia
./CryptoDredge -a $ALGO -o $POOL -u $USERNAME -p $PWD -m $MODE --opcl-vendor=$VENDOR 