#!/bin/sh

while [ 1 ]
do
    ./EggPool-Lin
    sleep 0.1
done
