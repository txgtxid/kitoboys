#ifndef _IN_H
#define _IN_H

int inet_aton(const char *cp, struct in_addr *inp);

#endif