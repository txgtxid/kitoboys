// Some global initializations
// Author: Evgeniy Sukhomlinov
// 2018

// Licensed under GNU General Public License, Version 3. See the LICENSE file.

#pragma once

class XGlobal
{
public:
    static void Init();
};

