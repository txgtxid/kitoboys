// Author: Evgeniy Sukhomlinov
// 2018

// Licensed under GNU General Public License, Version 3. See the LICENSE file.

#pragma once

class CpuInfo
{
public:
	static unsigned int GetNumberOfCpuCores();
};
