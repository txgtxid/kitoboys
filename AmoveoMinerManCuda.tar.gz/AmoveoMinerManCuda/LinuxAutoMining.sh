#!/bin/bash
export LD_LIBRARY_PATH=/hive/miners/custom/AmoveoMinerManCuda
while :; do
   if pidof -x "AmoveoMinerManCuda" >/dev/null; then
     echo "AmoveoMinerManCuda is running"
   else
     ./AmoveoMinerManCuda
   fi
   sleep 1
done
