#!/bin/bash
while :; do
   if pidof -x "AmoveoMinerManCuda" >/dev/null; then
     echo "AmoveoMinerManCuda is running"
   else
     ./AmoveoMinerManCuda
   fi
   sleep 1
done
